
/**
 * Start
 * Created by Lingwei Meng on 2017/10/21.
 */
public class Run {
    public static void main(String[] args){
        //RowData r=new RowData();
        //r.rowDataProcess();

        Analyze a=new Analyze();
        a.outputTimeAnalyze();
        //a.outputmemoryAnalyze();
    }
}
